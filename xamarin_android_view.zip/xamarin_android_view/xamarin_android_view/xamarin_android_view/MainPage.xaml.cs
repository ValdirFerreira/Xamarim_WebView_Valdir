﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace xamarin_android_view
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            //navegador.Source = "http://www.macoratti.net";
        }


        //private void PagOnNavigating(object sender, WebNavigatingEventArgs e)
        //{
        //    lblStatus.Text = "Carregando página...";
        //}
        //private void PagOnNavigated(object sender, WebNavigatedEventArgs e)
        //{
        //    lblStatus.Text = "Página carregada...";
        //}

    }
}
